# link-genie
Link Genie is a smart and dynamic link hub that lets users share multiple links through a single URL.  It features a clean black-green UI, editable profile with image upload, and a backend-powered system  designed to evolve into a rule-based, analytics-driven smart link hub for hackathons.
